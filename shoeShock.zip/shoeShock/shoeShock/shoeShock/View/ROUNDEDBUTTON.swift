//
//  ROUNDEDBUTTON.swift
//  shoeShock
//
//  Created by Juan Torres on 6/21/21.
//

import UIKit

class ROUNDEDBUTTON: UIButton {

    override  func awakeFromNib() {
        layer.cornerRadius = 15
    }

}
